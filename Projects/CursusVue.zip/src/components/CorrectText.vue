<template>
  <div id="pronouns">
    <p>
      <strong>Check yourself</strong>
    </p>
    <textarea class="textarea" v-model="text" von:keyup="checkText">{{text}}</textarea>
    <i v-bind:class="{ 'correct': correct, 'incorrect': !correct }"></i>
  </div>
</template>

<script>
var initialText, correctText;
initialText = "Me is sad because he is more clever than I.";
correctText = "I am sad because he is more clever than me.";

export default {
  name: "CorrectText",
  data() {
    return {
      text: initialText,
      correct: false
    };
  },
  methods: {
    checkText: function() {
      var text;
      text = this.text.trim();
      this.correct = text === correctText;
    }
  }
};
</script>

<style scoped>
</style>