<template>
    <div class="Component-1">
        <h1>{{ msg }}</h1>
        <p>Dit is component 1</p>
    </div>
</template>

<script>
    export default {
        name: 'Component-1',
        props: {
            msg: String,
        }
    };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>

