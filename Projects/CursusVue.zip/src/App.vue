<template>
  <div id="app">
    <Header />
    <AddTodo v-on:add-todo="addTodo" />
    <Todos v-bind:todos="todos" v-on:del-todo="deleteTodo" />
    <CorrectText />

    <div id="math">
      <h2>Vue Math Plugin</h2>
      <input v-model="item" />
      <hr />
      <div>
        Square:
        <span v-square="item"></span>
      </div>
      <div>
        Root:
        <span v-sqrt="item"></span>
      </div>
    </div>
  </div>
</template>

<script>
import Header from "./components/layout/Header";
import Todos from "./components/Todos.vue";
import AddTodo from "./components/AddTodo.vue";
import CorrectText from "./components/CorrectText.vue";
import axios from "axios";

export default {
  name: "app",
  components: {
    Header,
    AddTodo,
    Todos,
    CorrectText
  },
  data() {
    return {
      todos: [],
      item: 49
    };
  },
  methods: {
    deleteTodo(id) {
      axios
        .delete(`https://jsonplaceholder.typicode.com/todos/${id}`)
        .then(res => (this.todos = this.todos.filter(todo => todo.id !== id)))
        .catch(err => console.log(err));
    },
    addTodo(newTodo) {
      const { title, completed } = newTodo;

      axios
        .post("https://jsonplaceholder.typicode.com/todos", {
          title,
          completed
        })
        .then(res => (this.todos = [...this.todos, res.data]))
        .catch(err => console.log(err));

      this.todos = [...this.todos, newTodo];
    }
  },
  created() {
    axios
      .get("https://jsonplaceholder.typicode.com/todos?_limit=5")
      .then(res => (this.todos = res.data))
      .catch(err => console.log(err));
  }
};
</script>

<style></style>
